from sqlalchemy import inspect
from website import create_app
from website.models import db, User, Event  # seed tickets later after this works

app = create_app()

with app.app_context():
    print("DB URI =>", app.config["SQLALCHEMY_DATABASE_URI"])

    # start clean for local dev
    db.drop_all()
    db.create_all()

    # ---- seed users ----
    u1 = User(username="alice", email="alice@example.com", password_hash="hash1", role="attendee")
    u2 = User(username="bob",   email="bob@example.com",   password_hash="hash2", role="artist")

    # ---- seed events ----
    e1 = Event(
        title="Indie Night",
        description="Live indie bands.",
        date="2025-11-10 19:30",
        location="QUT Gardens Theatre",
        tickets_available=50,
        price=25.00,
    )
    e2 = Event(
        title="Tech Seminar",
        description="Talks on AI & data.",
        date="2025-12-05 10:00",
        location="B Block Auditorium",
        tickets_available=120,
        price=0.0,
    )

    db.session.add_all([u1, u2, e1, e2])
    db.session.commit()

    tables = inspect(db.engine).get_table_names()
    print("Tables in DB:", tables)
    print("✅ Seed complete")
